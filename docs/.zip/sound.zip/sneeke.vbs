command = "powershell.exe -nologo -ExecutionPolicy Unrestricted -File sound.ps1"
set shell = CreateObject("WScript.Shell")
shell.Run command,0