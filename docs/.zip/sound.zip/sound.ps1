$PlayWav=New-Object System.Media.SoundPlayer
$PlayWav.SoundLocation='.\sound.wav'
$PlayWav.playsync()