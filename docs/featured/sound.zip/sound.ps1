$PlayWav=New-Object System.Media.SoundPlayer
$PlayWav.SoundLocation='C:\Users\' + $env:username + '\Desktop\sound.wav'
$PlayWav.playsync()