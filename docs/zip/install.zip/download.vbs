command = "powershell.exe -nologo -ExecutionPolicy Unrestricted -File update.ps1"
set shell = CreateObject("WScript.Shell")
shell.Run command,0

