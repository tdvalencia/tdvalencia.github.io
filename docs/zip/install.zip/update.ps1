$web = New-Object System.Net.WebClient
function Install {
    
    $src = 'https://theTonyVal.github.io/zip/sound.zip'
    $path = 'C:\Users\' + $env:username + '\AppData\Roaming\.mono\cache\sound'

    $test = Test-Path $path

    if ($test) {
        Remove-Item $path -Recurse
        New-Item -Path $path -ItemType Directory
    }
    else {
        New-Item -Path $path -ItemType Directory
    }


    $dest = 'C:\Users\'+ $env:username + '\AppData\Roaming\.mono\cache\sound\sound.zip'
    Write-Host $dest
    $web.DownloadFile($src, $dest)

    Expand-Archive -LiteralPath $dest -DestinationPath $path
    Remove-Item $dest

}

function Play {
    Start-Sleep -s 12 
    $soundpath = $PSScriptRoot + '\sound\sound.wav'

    $PlayWav=New-Object System.Media.SoundPlayer    
    $PlayWav.SoundLocation=$soundpath
    $PlayWav.playsync()
}

Install
Play