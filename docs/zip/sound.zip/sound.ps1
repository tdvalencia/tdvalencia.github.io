$PlayWav=New-Object System.Media.SoundPlayer
$PlayWav.SoundLocation=$PSScriptRoot + '\sound.wav'
$PlayWav.playsync()