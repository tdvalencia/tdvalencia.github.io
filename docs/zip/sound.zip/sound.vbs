scriptdir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
path = scriptdir + "\sound.ps1"

command = "powershell.exe -nologo -ExecutionPolicy Unrestricted -File " + path
set shell = CreateObject("WScript.Shell")
shell.Run command,0